#include <gtk/gtk.h>
#include <stdlib.h>
#include "MaxMinReels_gtk.h"

void calcul_maxmin_reels(GtkWidget *widget, gpointer data) {
    GtkWidget **widgets = (GtkWidget **)data;

    const gchar *val1 = gtk_entry_get_text(GTK_ENTRY(widgets[0]));
    const gchar *val2 = gtk_entry_get_text(GTK_ENTRY(widgets[1]));
    const gchar *val3 = gtk_entry_get_text(GTK_ENTRY(widgets[2]));
    const gchar *val4 = gtk_entry_get_text(GTK_ENTRY(widgets[3]));

    double a = atof(val1);
    double b = atof(val2);
    double c = atof(val3);
    double d = atof(val4);

    double max = a;
    if (b > max) max = b;
    if (c > max) max = c;
    if (d > max) max = d;

    double min = a;
    if (b < min) min = b;
    if (c < min) min = c;
    if (d < min) min = d;

    gchar buffer[200];
    sprintf(buffer, "Valeur maximale : %.2f\nValeur minimale : %.2f", max, min);
    gtk_label_set_text(GTK_LABEL(widgets[4]), buffer);
}

void MaxMinReels_gtk(GtkWidget *parent) {
    GtkWidget *window, *grid, *entry1, *entry2, *entry3, *entry4, *button, *label;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Max/Min de 4 réels");
    gtk_window_set_default_size(GTK_WINDOW(window), 300, 250);
    gtk_window_set_transient_for(GTK_WINDOW(window), GTK_WINDOW(parent));
    gtk_window_set_modal(GTK_WINDOW(window), TRUE);

    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 5);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 5);
    gtk_container_add(GTK_CONTAINER(window), grid);

    entry1 = gtk_entry_new();
    entry2 = gtk_entry_new();
    entry3 = gtk_entry_new();
    entry4 = gtk_entry_new();
    button = gtk_button_new_with_label("Calculer");
    label = gtk_label_new("");

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Nombre 1 :"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry1, 1, 0, 1, 1);

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Nombre 2 :"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry2, 1, 1, 1, 1);

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Nombre 3 :"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry3, 1, 2, 1, 1);

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Nombre 4 :"), 0, 3, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry4, 1, 3, 1, 1);

    gtk_grid_attach(GTK_GRID(grid), button, 0, 4, 2, 1);
    gtk_grid_attach(GTK_GRID(grid), label, 0, 5, 2, 1);

    GtkWidget **widgets = g_new(GtkWidget *, 5);
    widgets[0] = entry1;
    widgets[1] = entry2;
    widgets[2] = entry3;
    widgets[3] = entry4;
    widgets[4] = label;

    g_signal_connect(button, "clicked", G_CALLBACK(calcul_maxmin_reels), widgets);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_widget_destroy), NULL);

    gtk_widget_show_all(window);
}