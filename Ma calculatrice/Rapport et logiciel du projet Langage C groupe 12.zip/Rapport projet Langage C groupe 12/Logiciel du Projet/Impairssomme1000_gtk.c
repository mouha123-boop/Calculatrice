#include <gtk/gtk.h>
#include "ImpairsSomme1000_gtk.h"

int somme_impairs_0_1000() {
    int somme = 0;
    for (int i = 1; i <= 1000; i += 2) {
        somme += i;
    }
    return somme;
}

void afficher_somme(GtkWidget *widget, gpointer data) {
    GtkWidget *label = GTK_WIDGET(data);
    int resultat = somme_impairs_0_1000();

    char buffer[100];
    sprintf(buffer, "Somme des impairs de 0 a 1000 : %d", resultat);
    gtk_label_set_text(GTK_LABEL(label), buffer);
}

void ImpairsSomme1000_gtk(GtkWidget *parent) {
    GtkWidget *window, *grid, *button, *label;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Somme des impairs de 0 a 1000");
    gtk_window_set_default_size(GTK_WINDOW(window), 350, 150);
    gtk_window_set_transient_for(GTK_WINDOW(window), GTK_WINDOW(parent));
    gtk_window_set_modal(GTK_WINDOW(window), TRUE);

    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 10);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 10);
    gtk_container_add(GTK_CONTAINER(window), grid);

    button = gtk_button_new_with_label("Calculer la somme");
    label = gtk_label_new("");

    gtk_grid_attach(GTK_GRID(grid), button, 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), label, 0, 1, 1, 1);

    g_signal_connect(button, "clicked", G_CALLBACK(afficher_somme), label);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_widget_destroy), NULL);

    gtk_widget_show_all(window);
}