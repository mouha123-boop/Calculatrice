#include <gtk/gtk.h>
#include <stdlib.h>
#include <string.h>
#include "Calculatrice_gtk.h"

void calculate(GtkWidget *widget, gpointer data) {
    GtkWidget **widgets = (GtkWidget **)data;
    GtkWidget *entry1 = widgets[0];      // First number entry°
    GtkWidget *entry2 = widgets[1];      // Second number entry
    GtkWidget *combo_box = widgets[2];   // Operator combo box
    GtkWidget *result_label = widgets[3]; // Result label

    const gchar *text1 = gtk_entry_get_text(GTK_ENTRY(entry1));
    const gchar *text2 = gtk_entry_get_text(GTK_ENTRY(entry2));
    const gchar *operator = gtk_combo_box_text_get_active_text(GTK_COMBO_BOX_TEXT(combo_box));

    double num1 = atof(text1);
    double num2 = atof(text2);
    double result = 0.0;
    gchar buffer[100];

    if (operator == NULL) {
        sprintf(buffer, "No operator selected");
    } else if (strcmp(operator, "+") == 0) {
        result = num1 + num2;
        sprintf(buffer, "%.2f", result);
    } else if (strcmp(operator, "-") == 0) {
        result = num1 - num2;
        sprintf(buffer, "%.2f", result);
    } else if (strcmp(operator, "*") == 0) {
        result = num1 * num2;
        sprintf(buffer, "%.2f", result);
    } else if (strcmp(operator, "/") == 0) {
        if (num2 != 0.0) {
            result = num1 / num2;
            sprintf(buffer, "%.2f", result);
        } else {
            sprintf(buffer, "Erreur : division par zéro");
        }
    } else {
        sprintf(buffer, "Opérateur invalide");
    }

    gtk_label_set_text(GTK_LABEL(result_label), buffer);
}

void Calculatrice_gtk(GtkWidget *parent) {
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Calculatrice");
    gtk_window_set_default_size(GTK_WINDOW(window), 300, 200);
    gtk_window_set_transient_for(GTK_WINDOW(window), GTK_WINDOW(parent));
    gtk_window_set_modal(GTK_WINDOW(window), TRUE);

    GtkWidget *grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    GtkWidget *entry1 = gtk_entry_new();
    GtkWidget *entry2 = gtk_entry_new();
    GtkWidget *combo_box = gtk_combo_box_text_new();
    GtkWidget *button = gtk_button_new_with_label("Calculer");
    GtkWidget *label_result = gtk_label_new("");

    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_box), "+");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_box), "-");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_box), "*");
    gtk_combo_box_text_append_text(GTK_COMBO_BOX_TEXT(combo_box), "/");

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Nombre 1:"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry1, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Nombre 2:"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry2, 1, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Opération:"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), combo_box, 1, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), button, 0, 3, 2, 1);
    gtk_grid_attach(GTK_GRID(grid), label_result, 0, 4, 2, 1);

    GtkWidget **widgets = g_new(GtkWidget *, 4);
    widgets[0] = entry1;
    widgets[1] = entry2;
    widgets[2] = combo_box;
    widgets[3] = label_result;

    g_signal_connect(button, "clicked", G_CALLBACK(calculate), widgets);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_widget_destroy), NULL);

    gtk_widget_show_all(window);
}