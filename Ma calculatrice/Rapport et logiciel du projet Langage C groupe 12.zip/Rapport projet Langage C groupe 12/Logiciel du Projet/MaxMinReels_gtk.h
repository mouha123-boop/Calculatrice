#ifndef MAXMINREELS_GTK_H
#define MAXMINREELS_GTK_H

#include <gtk/gtk.h>

void MaxMinReels_gtk(GtkWidget *parent);

#endif