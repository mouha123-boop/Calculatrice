#include <gtk/gtk.h>
#include "Identite_gtk.h"
#include "Calculatrice_gtk.h"
#include "MaxMinReels_gtk.h"
#include "Primalite_gtk.h"
#include "ImpairsSomme1000_gtk.h"
#include "Systeme3_gtk.h"
#include "Equation2nd_gtk.h"

void on_menu_item_clicked(GtkWidget *widget, gpointer data) {
    void (**fonctions)(GtkWidget *) = data;  // ✅ Pointeur vers tableau de fonctions

    const gchar *label = gtk_button_get_label(GTK_BUTTON(widget));
    if (g_strcmp0(label, "Identite") == 0)
        fonctions[0](GTK_WIDGET(gtk_widget_get_toplevel(widget)));
    else if (g_strcmp0(label, "Calculatrice") == 0)
        fonctions[1](GTK_WIDGET(gtk_widget_get_toplevel(widget)));
    else if (g_strcmp0(label, "Max/Min Reels") == 0)
        fonctions[2](GTK_WIDGET(gtk_widget_get_toplevel(widget)));
    else if (g_strcmp0(label, "Primalite") == 0)
        fonctions[3](GTK_WIDGET(gtk_widget_get_toplevel(widget)));
    else if (g_strcmp0(label, "Somme des impairs") == 0)
        fonctions[4](GTK_WIDGET(gtk_widget_get_toplevel(widget)));
    else if (g_strcmp0(label, "Systeme a 3 inconnues") == 0)
        fonctions[5](GTK_WIDGET(gtk_widget_get_toplevel(widget)));
    else if (g_strcmp0(label, "Equation du 2nd degre") == 0)
        fonctions[6](GTK_WIDGET(gtk_widget_get_toplevel(widget)));
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    GtkWidget *window, *grid;
    GtkWidget *buttons[7];
    const char *labels[] = {
        "Identite",
        "Calculatrice",
        "Max/Min Reels",
        "Primalite",
        "Somme des impairs",
        "Systeme a 3 inconnues",
        "Equation du 2nd degre"
    };

    void (*fonctions[])(GtkWidget *) = {
        Identite_gtk,
        Calculatrice_gtk,
        MaxMinReels_gtk,
        Primalite_gtk,
        ImpairsSomme1000_gtk,
        Systeme3Inconnues_gtk,
        EquationSecondDegre_gtk
    };

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Notreprojet_app");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 400);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    for (int i = 0; i < 7; i++) {
        buttons[i] = gtk_button_new_with_label(labels[i]);
        gtk_grid_attach(GTK_GRID(grid), buttons[i], 0, i, 1, 1);
        g_signal_connect(buttons[i], "clicked", G_CALLBACK(on_menu_item_clicked), fonctions);
    }

    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}