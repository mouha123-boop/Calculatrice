#ifndef IMPAIRSSOMME1000_GTK_H
#define IMPAIRSSOMME1000_GTK_H

#include <gtk/gtk.h>

void ImpairsSomme1000_gtk(GtkWidget *parent);

#endif