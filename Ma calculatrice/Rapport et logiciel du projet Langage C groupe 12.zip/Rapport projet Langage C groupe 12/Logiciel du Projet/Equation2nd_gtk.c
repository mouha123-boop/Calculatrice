#include <gtk/gtk.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include "Equation2nd_gtk.h"

void on_resoudre_clicked(GtkWidget *widget, gpointer data) {
    GtkWidget **widgets = (GtkWidget **)data;

    const char *a_text = gtk_entry_get_text(GTK_ENTRY(widgets[0]));
    const char *b_text = gtk_entry_get_text(GTK_ENTRY(widgets[1]));
    const char *c_text = gtk_entry_get_text(GTK_ENTRY(widgets[2]));

    double a = atof(a_text);
    double b = atof(b_text);
    double c = atof(c_text);

    char buffer[256];
    double delta = b * b - 4 * a * c;

    if (a == 0) {
        sprintf(buffer, "Ce n'est pas une équation du second degré !");
    } else if (delta > 0) {
        double x1 = (-b + sqrt(delta)) / (2 * a);
        double x2 = (-b - sqrt(delta)) / (2 * a);
        sprintf(buffer, "Deux solutions réelles :\n x1 = %.2lf\n x2 = %.2lf", x1, x2);
    } else if (delta == 0) {
        double x = -b / (2 * a);
        sprintf(buffer, "Une solution réelle double :\n x = %.2lf", x);
    } else {
        sprintf(buffer, "Pas de solution réelle (delta = %.2lf)", delta);
    }

    gtk_label_set_text(GTK_LABEL(widgets[3]), buffer);
}

void EquationSecondDegre_gtk(GtkWidget *parent) {
    GtkWidget *window, *grid, *button, *label;
    GtkWidget *entry_a, *entry_b, *entry_c;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Équation du second degré");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 200);
    gtk_window_set_transient_for(GTK_WINDOW(window), GTK_WINDOW(parent));
    gtk_window_set_modal(GTK_WINDOW(window), TRUE);

    grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    entry_a = gtk_entry_new();
    entry_b = gtk_entry_new();
    entry_c = gtk_entry_new();
    label = gtk_label_new("");

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("a :"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry_a, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("b :"), 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry_b, 1, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("c :"), 0, 2, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry_c, 1, 2, 1, 1);

    button = gtk_button_new_with_label("Résoudre");
    gtk_grid_attach(GTK_GRID(grid), button, 0, 3, 2, 1);
    gtk_grid_attach(GTK_GRID(grid), label, 0, 4, 2, 1);

    GtkWidget **widgets = g_malloc(sizeof(GtkWidget *) * 4);
    widgets[0] = entry_a;
    widgets[1] = entry_b;
    widgets[2] = entry_c;
    widgets[3] = label;

    g_signal_connect(button, "clicked", G_CALLBACK(on_resoudre_clicked), widgets);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_widget_destroy), NULL);

    gtk_widget_show_all(window);
}