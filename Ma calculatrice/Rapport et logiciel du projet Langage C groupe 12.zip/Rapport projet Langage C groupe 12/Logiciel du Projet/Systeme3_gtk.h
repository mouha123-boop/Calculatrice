#ifndef SYSTEME3_GTK_H
#define SYSTEME3_GTK_H

#include <gtk/gtk.h>

void Systeme3Inconnues_gtk(GtkWidget *parent);

#endif