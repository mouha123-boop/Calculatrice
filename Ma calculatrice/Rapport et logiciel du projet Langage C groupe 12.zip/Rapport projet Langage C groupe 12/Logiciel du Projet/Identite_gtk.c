#include <gtk/gtk.h>
#include "Identite_gtk.h"

void afficher_identite(GtkWidget *widget, gpointer data) {
    GtkWidget **widgets = (GtkWidget **)data;
    GtkEntry *entryNom = GTK_ENTRY(widgets[0]);
    GtkEntry *entryAge = GTK_ENTRY(widgets[1]);
    GtkLabel *labelResult = GTK_LABEL(widgets[2]);

    const gchar *nom = gtk_entry_get_text(entryNom);
    const gchar *age = gtk_entry_get_text(entryAge);

    gchar *texte = g_strdup_printf("Nom : %s\nÂge : %s ans", nom, age);
    gtk_label_set_text(labelResult, texte);
    g_free(texte);
}

void Identite_gtk(GtkWidget *widget) {
    GtkWidget *window;
    GtkWidget *grid;
    GtkWidget *labelNom, *labelAge, *entryNom, *entryAge;
    GtkWidget *button;
    GtkWidget *labelResult;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Identité");
    gtk_window_set_default_size(GTK_WINDOW(window), 300, 200);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_widget_destroy), NULL);

    grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    labelNom = gtk_label_new("Nom:");
    entryNom = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grid), labelNom, 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entryNom, 1, 0, 1, 1);

    labelAge = gtk_label_new("Âge:");
    entryAge = gtk_entry_new();
    gtk_grid_attach(GTK_GRID(grid), labelAge, 0, 1, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entryAge, 1, 1, 1, 1);

    button = gtk_button_new_with_label("Afficher");
    gtk_grid_attach(GTK_GRID(grid), button, 0, 2, 2, 1);

    labelResult = gtk_label_new("");
    gtk_grid_attach(GTK_GRID(grid), labelResult, 0, 3, 2, 1);

    GtkWidget **donnees = g_new(GtkWidget *, 3);
    donnees[0] = entryNom;
    donnees[1] = entryAge;
    donnees[2] = labelResult;

    g_signal_connect(button, "clicked", G_CALLBACK(afficher_identite), donnees);

    gtk_widget_show_all(window);
}