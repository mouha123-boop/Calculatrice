#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include "Systeme3_gtk.h"

void resoudre_systeme(double a1, double b1, double c1, double d1,
                      double a2, double b2, double c2, double d2,
                      double a3, double b3, double c3, double d3,
                      double *x, double *y, double *z) {
    double D, Dx, Dy, Dz;

    D  = a1 * (b2 * c3 - b3 * c2) - b1 * (a2 * c3 - a3 * c2) + c1 * (a2 * b3 - a3 * b2);
    Dx = d1 * (b2 * c3 - b3 * c2) - b1 * (d2 * c3 - d3 * c2) + c1 * (d2 * b3 - d3 * b2);
    Dy = a1 * (d2 * c3 - d3 * c2) - d1 * (a2 * c3 - a3 * c2) + c1 * (a2 * d3 - a3 * d2);
    Dz = a1 * (b2 * d3 - b3 * d2) - b1 * (a2 * d3 - a3 * d2) + d1 * (a2 * b3 - a3 * b2);

    if (D != 0) {
        *x = Dx / D;
        *y = Dy / D;
        *z = Dz / D;
    } else {
        *x = *y = *z = 0;
    }
}

void on_calculer_clicked(GtkWidget *widget, gpointer data) {
    GtkWidget **entries = (GtkWidget **)data;
    double vals[12];
    char buffer[512];
    for (int i = 0; i < 12; ++i) {
        const char *txt = gtk_entry_get_text(GTK_ENTRY(entries[i]));
        vals[i] = atof(txt);
    }

    double x, y, z;
    resoudre_systeme(vals[0], vals[1], vals[2], vals[3],
                     vals[4], vals[5], vals[6], vals[7],
                     vals[8], vals[9], vals[10], vals[11],
                     &x, &y, &z);

    sprintf(buffer, "Résultat :\n x = %.2lf\n y = %.2lf\n z = %.2lf", x, y, z);
    gtk_label_set_text(GTK_LABEL(entries[12]), buffer);
}

void Systeme3Inconnues_gtk(GtkWidget *parent) {
    GtkWidget *window, *grid, *button, *label;
    GtkWidget *entries[12];
    GtkWidget *labels[12];
    const char *textes[] = {
        "a1", "b1", "c1", "d1",
        "a2", "b2", "c2", "d2",
        "a3", "b3", "c3", "d3"
    };

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Système à 3 inconnues");
    gtk_window_set_default_size(GTK_WINDOW(window), 400, 400);
    gtk_window_set_transient_for(GTK_WINDOW(window), GTK_WINDOW(parent));
    gtk_window_set_modal(GTK_WINDOW(window), TRUE);

    grid = gtk_grid_new();
    gtk_container_add(GTK_CONTAINER(window), grid);

    for (int i = 0; i < 12; ++i) {
        labels[i] = gtk_label_new(textes[i]);
        entries[i] = gtk_entry_new();
        gtk_grid_attach(GTK_GRID(grid), labels[i], 0, i, 1, 1);
        gtk_grid_attach(GTK_GRID(grid), entries[i], 1, i, 1, 1);
    }

    button = gtk_button_new_with_label("Résoudre");
    label = gtk_label_new("");

    gtk_grid_attach(GTK_GRID(grid), button, 0, 12, 2, 1);
    gtk_grid_attach(GTK_GRID(grid), label, 0, 13, 2, 1);

    GtkWidget **all_widgets = g_malloc(sizeof(GtkWidget *) * 13);
    for (int i = 0; i < 12; ++i)
        all_widgets[i] = entries[i];
    all_widgets[12] = label;

    g_signal_connect(button, "clicked", G_CALLBACK(on_calculer_clicked), all_widgets);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_widget_destroy), NULL);

    gtk_widget_show_all(window);
}