#ifndef EQUATION2ND_GTK_H
#define EQUATION2ND_GTK_H

#include <gtk/gtk.h>

void EquationSecondDegre_gtk(GtkWidget *parent);

#endif