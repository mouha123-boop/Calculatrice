#ifndef PRIMALITE_GTK_H
#define PRIMALITE_GTK_H

#include <gtk/gtk.h>

void Primalite_gtk(GtkWidget *parent);

#endif