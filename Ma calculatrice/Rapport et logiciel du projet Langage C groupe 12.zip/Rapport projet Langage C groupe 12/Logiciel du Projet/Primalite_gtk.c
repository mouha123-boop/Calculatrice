#include <gtk/gtk.h>
#include <math.h>
#include "Primalite_gtk.h"

int est_premier(int n) {
    if (n <= 1) return 0;
    if (n == 2) return 1;
    if (n % 2 == 0) return 0;
    for (int i = 3; i <= sqrt(n); i += 2) {
        if (n % i == 0) return 0;
    }
    return 1;
}

void verifier_primalite(GtkWidget *widget, gpointer data) {
    GtkWidget **widgets = (GtkWidget **)data;

    const gchar *texte = gtk_entry_get_text(GTK_ENTRY(widgets[0]));
    int n = atoi(texte);

    gchar buffer[100];
    if (est_premier(n)) {
        sprintf(buffer, "%d est un nombre premier.", n);
    } else {
        sprintf(buffer, "%d n'est pas un nombre premier.", n);
    }

    gtk_label_set_text(GTK_LABEL(widgets[1]), buffer);
}

void Primalite_gtk(GtkWidget *parent) {
    GtkWidget *window, *grid, *entry, *button, *label;

    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Tester la primalité");
    gtk_window_set_default_size(GTK_WINDOW(window), 300, 150);
    gtk_window_set_transient_for(GTK_WINDOW(window), GTK_WINDOW(parent));
    gtk_window_set_modal(GTK_WINDOW(window), TRUE);

    grid = gtk_grid_new();
    gtk_grid_set_row_spacing(GTK_GRID(grid), 10);
    gtk_grid_set_column_spacing(GTK_GRID(grid), 10);
    gtk_container_add(GTK_CONTAINER(window), grid);

    entry = gtk_entry_new();
    gtk_entry_set_placeholder_text(GTK_ENTRY(entry), "Entrez un entier");

    button = gtk_button_new_with_label("Vérifier");
    label = gtk_label_new("");

    gtk_grid_attach(GTK_GRID(grid), gtk_label_new("Nombre :"), 0, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), entry, 1, 0, 1, 1);
    gtk_grid_attach(GTK_GRID(grid), button, 0, 1, 2, 1);
    gtk_grid_attach(GTK_GRID(grid), label, 0, 2, 2, 1);

    GtkWidget **widgets = g_new(GtkWidget *, 2);
    widgets[0] = entry;
    widgets[1] = label;

    g_signal_connect(button, "clicked", G_CALLBACK(verifier_primalite), widgets);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_widget_destroy), NULL);

    gtk_widget_show_all(window);
}