#ifndef IDENTITE_GTK_H
#define IDENTITE_GTK_H

#include <gtk/gtk.h>

void Identite_gtk(GtkWidget *parent);

#endif // IDENTITE_GTK_H