#ifndef CALCULATRICE_GTK_H
#define CALCULATRICE_GTK_H

#include <gtk/gtk.h>

void Calculatrice_gtk(GtkWidget *parent);

#endif